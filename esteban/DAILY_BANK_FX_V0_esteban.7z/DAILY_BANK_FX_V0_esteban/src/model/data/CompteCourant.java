package model.data;

public class CompteCourant {

	//attributs
	public int idNumCompte;
	public int debitAutorise;
	public double solde;
	public String estCloture; // "O" ou "N"
	public int idNumCli;

	//constructeur parametre
	public CompteCourant(int idNumCompte, int debitAutorise, double solde, String estCloture, int idNumCli) {
		super();
		this.idNumCompte = idNumCompte;
		this.debitAutorise = debitAutorise;
		this.solde = solde;
		this.estCloture = estCloture;
		this.idNumCli = idNumCli;
	}

	//constructeur permettant de creer un compte a partir des informations d'un compte deja existant
	public CompteCourant(CompteCourant cc) {
		this(cc.idNumCompte, cc.debitAutorise, cc.solde, cc.estCloture, cc.idNumCli);
	}

	//constructeur sans parametres, qui definit donc la cloture du compte à "non" automatiquement
	public CompteCourant() {
		this(0, 0, 0, "N", -1000);
	}

	//methode permettant d'afficher les infos d'un compte
	@Override
	public String toString() {
		String s = "" + String.format("%05d", this.idNumCompte) + " : Solde=" + String.format("%12.02f", this.solde)
				+ "  ,  DÃ©couvert Autorise=" + String.format("%8d", this.debitAutorise);
		if (this.estCloture == null) {
			s = s + " (Cloture)";
		} else {
			s = s + (this.estCloture.equals("N") ? " (Ouvert)" : " (Cloture)");
		}
		return s;
	}
	
	/**
	 * Permet d'obtenir le num�ro d'un Compte.<BR>
	 * <BR>
	 * 
	 * @return Le num�ro du Compte.
	 */
	public int getNumCompte() {
		return this.idNumCompte;
	}
	
	/**
	 * Permet d'effectuer un retrait sur un Compte.<BR>
	 * <BR>
	 * Effectue un retrait (d�bit) de pSomme Euros sur le Compte.<BR>
	 * L�ve une exception si pSomme < 0. <BR>
	 * 
	 * @param pSomme
	 *            Le montant retir� sur le Compte.
	 * @throws CompteException
	 *             Lorsque pSomme < 0
	 * @see Compte#deposer(double)
	 */
	public void debiter (double pSomme) throws Exception {
		if (pSomme < 0) {
			throw new Exception(
					"Erreur de somme n�gative lors d'un retrait sur " + this.idNumCompte);
		}
		
		if (this.solde - pSomme <0 ) {
			throw new Exception ("Erreur, le compte n'a pas un solde assez important pour ce débit.");
		}
		
		this.solde -= pSomme;
	}
	

	/**
	 * Permet d'effectuer un d�pot sur un Compte.<BR>
	 * <BR>
	 * Effectue un d�pot (cr�dit) de pSomme Euros sur le Compte.<BR>
	 * L�ve une exception si pSomme < 0.<BR>
	 * 
	 * @param pSomme
	 *            Le montant d�pos� sur le Compte.
	 * @throws CompteException
	 *             Lorsque pSomme < 0
	 * @see Compte#retirer(double)
	 */
	public void crediter(double pSomme) throws Exception {
		if (pSomme < 0) {
			throw new Exception(
					"Erreur de somme n�gative lors d'un d�pot sur " + this.idNumCompte);
		}
		this.solde += pSomme;
	}
	
	//permet d'effectuer un virement d'un compte à l'autre
	public void virement(CompteCourant debiteur, CompteCourant crediteur, double pSomme) throws Exception {
		debiteur.debiter(pSomme);
		crediteur.crediter(pSomme);
		System.out.println("Virement effectué du compte " + debiteur.getNumCompte() + "au compte " + crediteur.getNumCompte() + ", d'une valeur de : " + pSomme);
	}
	
	//methode permettant de cloturer un compte
	public void cloturer(CompteCourant c) {
		this.estCloture = "O";
	}
	

}
