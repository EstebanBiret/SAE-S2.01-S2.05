package application;

import application.control.DailyBankMainFrame;

public class DailyBankApp  {

	public static void main(String[] args) {

		//permet de lancer l'application
		DailyBankMainFrame.runApp();

	}
}

//WorkSpace d'Esteban

