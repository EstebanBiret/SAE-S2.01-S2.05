package application;

import application.tools.ConstantesIHM;
import model.data.AgenceBancaire;
import model.data.Employe;

public class DailyBankState {
	
	//attributs
	private Employe empAct;
	private AgenceBancaire agAct;
	private boolean isChefDAgence;

	//getter
	public Employe getEmpAct() {
		return this.empAct;
	}

	//setter
	public void setEmpAct(Employe employeActif) {
		this.empAct = employeActif;
	}

	//getter
	public AgenceBancaire getAgAct() {
		return this.agAct;
	}

	//setter d'une AgenceBancaire
	public void setAgAct(AgenceBancaire agenceActive) {
		this.agAct = agenceActive;
	}

	//methode booleene permettant de savoir si une personne est chef d'agence ou non 
	public boolean isChefDAgence() {
		return this.isChefDAgence;
	}

	//setter d'un chef d'Agence booleen, en fonction de si il est deja chef ou non
	public void setChefDAgence(boolean isChefDAgence) {
		this.isChefDAgence = isChefDAgence;
	}

	//setter d'un chef d'Agence 
	public void setChefDAgence(String droitsAccess) {
		this.isChefDAgence = false;

		if (droitsAccess.equals(ConstantesIHM.AGENCE_CHEF)) {
			this.isChefDAgence = true;
		}
	}
}
